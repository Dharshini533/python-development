class Student:
    def display_details(self):
        self.name = "Dharshini"
        self.dept = "ECE"
        print("Name:", self.name)
        print("Department:", self.dept)

s1 = Student()
s1.display_details()