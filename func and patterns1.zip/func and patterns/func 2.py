def square(n):
    for i in range(n):
        print("*" * n)

square(4)